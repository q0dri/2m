<?php

namespace InstagramAPI\Exception;

class ChallengeRequiredException extends RequestException
{
}
